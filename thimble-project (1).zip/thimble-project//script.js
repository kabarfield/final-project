$(document).ready(function(){
  $('.parallax').parallax();
});

var elem = document.querySelector('.parallax');
var instance = M.Parallax.init(elem, options);

// Or with jQuery

$(document).ready(function(){
  $('.parallax').parallax();
});